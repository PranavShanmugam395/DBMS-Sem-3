import { User, Game, Purchase, Review, WishlistItem } from './types';

export const INITIAL_USERS: User[] = [
    { user_id: 1, username: "Pranav", password: "Pranav", balance: 5000, role: "user" },
    { user_id: 2, username: "Sujit", password: "Sujit", balance: 5000, role: "user" },
    { user_id: 3, username: "Dev", password: "Dev", balance: 0, role: "developer" },
    { user_id: 4, username: "GamerX95", password: "GamerX95", balance: 5000, role: "user" },
    { user_id: 5, username: "PixelPioneer", password: "PixelPioneer", balance: 5000, role: "user" },
    { user_id: 6, username: "QuestQueen", password: "QuestQueen", balance: 5000, role: "user" }
];

export const INITIAL_GAMES: Game[] = [
    { game_id: 1, name: "Hades", price: 500, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1145360/header.jpg", genre: "Action Roguelike", releaseDate: "2020-09-17", description: "Defy the god of the dead as you hack and slash out of the Underworld in this rogue-like dungeon crawler." },
    { game_id: 2, name: "Celeste", price: 300, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/504230/header.jpg", genre: "Platformer", releaseDate: "2018-01-25", description: "Help Madeline survive her inner demons on her journey to the top of Celeste Mountain in this super-tight platformer." },
    { game_id: 3, name: "GTA V", price: 1500, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg", genre: "Action-Adventure", releaseDate: "2015-04-14", description: "Explore the stunning world of Los Santos and Blaine County in the ultimate Grand Theft Auto V experience." },
    { game_id: 4, name: "The Witcher 3: Wild Hunt", price: 1200, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/292030/header.jpg", genre: "RPG", releaseDate: "2015-05-18", description: "As monster hunter Geralt of Rivia, take on the most important contract of your life: to find the child of prophecy." },
    { game_id: 5, name: "Cyberpunk 2077", price: 1800, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1091500/header.jpg", genre: "RPG", releaseDate: "2020-12-10", description: "Become a cyber-enhanced mercenary in a sprawling futuristic metropolis obsessed with power, glamour, and body modification." },
    { game_id: 6, name: "Red Dead Redemption 2", price: 2000, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1174180/header.jpg", genre: "Action-Adventure", releaseDate: "2019-12-05", description: "Experience an epic tale of honor and loyalty at the dawn of the modern age in a vast and atmospheric world." },
    { game_id: 7, name: "Elden Ring", price: 2500, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1245620/header.jpg", genre: "RPG", releaseDate: "2022-02-25", description: "Unravel the mysteries of the Elden Ring's power in the vast and dangerous Lands Between." },
    { game_id: 8, name: "Stardew Valley", price: 400, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/413150/header.jpg", genre: "Simulation", releaseDate: "2016-02-26", description: "Create the farm of your dreams in this charming and open-ended country-life RPG." },
    { game_id: 9, name: "Hollow Knight", price: 600, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/367520/header.jpg", genre: "Metroidvania", releaseDate: "2017-02-24", description: "Explore a vast, interconnected world in this beautifully animated action-adventure about a knight and an ancient kingdom." },
    { game_id: 10, name: "Minecraft", price: 1000, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/2050650/header.jpg", genre: "Sandbox", releaseDate: "2011-11-18", description: "A game about placing blocks and going on adventures in a world with virtually limitless possibilities." },
    { game_id: 11, name: "Terraria", price: 350, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/105600/header.jpg", genre: "Sandbox", releaseDate: "2011-05-16", description: "Dig, fight, explore, and build in this 2D action-adventure game with a focus on crafting and exploration." },
    { game_id: 12, name: "Portal 2", price: 250, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/620/header.jpg", genre: "Puzzle", releaseDate: "2011-04-19", description: "The highly anticipated sequel to 2007's Game of the Year, Portal 2 is a hilariously mind-bending adventure." },
    { game_id: 13, name: "The Elder Scrolls V: Skyrim", price: 1100, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/489830/header.jpg", genre: "RPG", releaseDate: "2011-11-11", description: "Winner of more than 200 Game of the Year Awards, Skyrim reimagines and revolutionizes the open-world fantasy epic." },
    { game_id: 14, name: "Baldur's Gate 3", price: 3000, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1086940/header.jpg", genre: "RPG", releaseDate: "2023-08-03", description: "Gather your party and return to the Forgotten Realms in a tale of fellowship, betrayal, sacrifice, and survival." },
    { game_id: 15, name: "Counter-Strike 2", price: 0, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/730/header.jpg", genre: "FPS", releaseDate: "2023-09-27", description: "The next chapter in the world's #1 first-person shooter, delivering an upgrade to every system, every piece of content, and every part of the C-S experience." },
    { game_id: 16, name: "Dota 2", price: 0, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/570/header.jpg", genre: "MOBA", releaseDate: "2013-07-09", description: "Every day, millions of players worldwide enter battle as one of over a hundred Dota heroes in a 5v5 team clash." },
    { game_id: 17, name: "Apex Legends", price: 0, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1172470/header.jpg", genre: "FPS", releaseDate: "2019-02-04", description: "Conquer with character in this free-to-play Hero shooter where legendary characters with powerful abilities team up." },
    { game_id: 18, name: "Valheim", price: 550, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/892970/header.jpg", genre: "Survival", releaseDate: "2021-02-02", description: "A brutal exploration and survival game for 1-10 players, set in a procedurally-generated purgatory inspired by viking culture." },
    { game_id: 19, name: "Subnautica", price: 700, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/264710/header.jpg", genre: "Survival", releaseDate: "2018-01-23", description: "Descend into the depths of an alien underwater world filled with wonder and peril." },
    { game_id: 20, name: "Outer Wilds", price: 800, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/753640/header.jpg", genre: "Exploration", releaseDate: "2020-06-18", description: "Explore for the sake of curiosity in a hand-crafted solar system trapped in an endless time loop." },
    { game_id: 21, name: "Disco Elysium", price: 900, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/632470/header.jpg", genre: "RPG", releaseDate: "2019-10-15", description: "A groundbreaking open world role playing game where you're a detective with a unique skill system at your disposal." },
    { game_id: 22, name: "Divinity: Original Sin 2", price: 1300, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/435150/header.jpg", genre: "RPG", releaseDate: "2017-09-14", description: "The critically acclaimed RPG that raised the bar, from the creators of Baldur's Gate 3." },
    { game_id: 23, name: "Slay the Spire", price: 450, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/646570/header.jpg", genre: "Deck-builder", releaseDate: "2019-01-23", description: "A fusion of card games and roguelikes that's the best single player deckbuilder." },
    { game_id: 24, name: "Helldivers 2", price: 2499, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/553850/header.jpg", genre: "Co-op Shooter", releaseDate: "2024-02-08", description: "Join the elite forces of the Helldivers and fight for freedom across a hostile galaxy in this fast-paced third-person shooter." },
    { game_id: 25, name: "Lethal Company", price: 289, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1966720/header.jpg", genre: "Co-op Horror", releaseDate: "2023-10-23", description: "A co-op horror game about scavenging abandoned moons for scrap to meet the Company's profit quota." },
    { game_id: 26, name: "Palworld", price: 899, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1623730/header.jpg", genre: "Survival", releaseDate: "2024-01-19", description: "Fight, farm, build, and work alongside mysterious creatures called 'Pals' in this all-new multiplayer monster-collecting game." },
    { game_id: 27, name: "Dave the Diver", price: 549, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1868140/header.jpg", genre: "Adventure", releaseDate: "2023-06-28", description: "Explore a mysterious deep sea trench by day and run a sushi restaurant by night." },
    { game_id: 28, name: "Manor Lords", price: 999, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/1363080/header.jpg", genre: "Strategy", releaseDate: "2024-04-26", description: "A medieval strategy game featuring in-depth city building, large-scale tactical battles, and complex economic simulations." },
    { game_id: 29, name: "Deep Rock Galactic", price: 699, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/548430/header.jpg", genre: "Co-op FPS", releaseDate: "2020-05-13", description: "A 1-4 player co-op FPS featuring badass space Dwarves, 100% destructible environments, and procedurally-generated caves." },
    { game_id: 30, name: "No Man's Sky", price: 1799, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/275850/header.jpg", genre: "Exploration", releaseDate: "2016-08-12", description: "An epic science fiction adventure set across an infinite universe, in which every star is the light of a distant sun." },
    { game_id: 31, name: "Risk of Rain 2", price: 699, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/632360/header.jpg", genre: "Action Roguelike", releaseDate: "2020-08-11", description: "Escape a chaotic alien planet by fighting through hordes of frenzied monsters with your friends, or on your own." },
    { game_id: 32, name: "Ghost of Tsushima", price: 3999, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/2215430/header.jpg", genre: "Action-Adventure", releaseDate: "2024-05-16", description: "Forge a new path and wage an unconventional war for the freedom of Tsushima in this open-world action adventure." },
    { game_id: 33, name: "Factorio", price: 1000, imageUrl: "https://cdn.akamai.steamstatic.com/steam/apps/427520/header.jpg", genre: "Simulation", releaseDate: "2020-08-14", description: "A game about building and creating automated factories to produce items of increasing complexity." },
];


export const INITIAL_PURCHASES: Purchase[] = [
    // Purchases for Pranav (user_id: 1)
    { user_id: 1, game_id: 1 }, { user_id: 1, game_id: 4 }, { user_id: 1, game_id: 6 },
    { user_id: 1, game_id: 8 }, { user_id: 1, game_id: 12 }, { user_id: 1, game_id: 14 },
    { user_id: 1, game_id: 19 }, { user_id: 1, game_id: 23 },
    // Purchases for Sujit (user_id: 2)
    { user_id: 2, game_id: 2 }, { user_id: 2, game_id: 1 }, { user_id: 2, game_id: 4 },
    { user_id: 2, game_id: 7 }, { user_id: 2, game_id: 9 }, { user_id: 2, game_id: 13 },
    { user_id: 2, game_id: 18 }, { user_id: 2, game_id: 21 },
    // Purchases for new users to validate their reviews
    { user_id: 4, game_id: 3 }, { user_id: 4, game_id: 5 }, { user_id: 4, game_id: 9 },
    { user_id: 5, game_id: 6 }, { user_id: 5, game_id: 8 }, { user_id: 5, game_id: 20 }, { user_id: 5, game_id: 21 },
    { user_id: 6, game_id: 4 }, { user_id: 6, game_id: 7 }, { user_id: 6, game_id: 14 }, { user_id: 6, game_id: 22 },
    { user_id: 4, game_id: 24}, { user_id: 5, game_id: 25}, { user_id: 6, game_id: 32},
    { user_id: 1, game_id: 29}, { user_id: 2, game_id: 31}, { user_id: 4, game_id: 27},
    { user_id: 5, game_id: 33}, { user_id: 6, game_id: 26},
];
export const INITIAL_REVIEWS: Review[] = [
    { user_id: 1, game_id: 1, rating: 5, review: "An absolute masterpiece of the roguelike genre. The story, art, and gameplay are all top-notch." },
    { user_id: 2, game_id: 2, rating: 5, review: "A challenging but incredibly rewarding platformer with a touching story." },
    { user_id: 2, game_id: 1, rating: 4, review: "Really fun, but can be a bit repetitive after many runs." },
    { user_id: 1, game_id: 4, rating: 5, review: "One of the best RPGs ever made. The world is massive and full of content." },
    { user_id: 2, game_id: 4, rating: 5, review: "Geralt's story is incredible. A must-play for any fantasy fan." },
    { user_id: 1, game_id: 6, rating: 5, review: "The level of detail in this game is breathtaking. The story is a cinematic masterpiece." },
    { user_id: 2, game_id: 7, rating: 4, review: "Incredibly difficult but so rewarding when you finally beat a boss. The world is mysterious and beautiful." },
    { user_id: 1, game_id: 8, rating: 5, review: "The perfect game to relax and unwind with. So charming and addictive." },
    { user_id: 2, game_id: 9, rating: 5, review: "A beautiful and challenging Metroidvania. The art style is stunning." },
    { user_id: 1, game_id: 12, rating: 5, review: "Peak puzzle game design. The co-op is hilarious and brilliant." },
    { user_id: 2, game_id: 13, rating: 4, review: "I've sunk hundreds of hours into this game. It's a classic for a reason, despite the bugs." },
    { user_id: 1, game_id: 14, rating: 5, review: "The gold standard for CRPGs. The amount of choice is staggering." },
    { user_id: 2, game_id: 18, rating: 4, review: "Building and exploring with friends in this Viking world is so much fun." },
    { user_id: 1, game_id: 19, rating: 4, review: "Genuinely terrifying but an amazing survival and exploration game." },
    { user_id: 2, game_id: 21, rating: 5, review: "There is no other game like this. The writing is phenomenal. A true work of art." },
    { user_id: 1, game_id: 23, rating: 5, review: "The best deck-builder out there. Infinitely replayable." },
    // Reviews from new users
    { user_id: 4, game_id: 3, rating: 4, review: "Chaos and fun, what more could you want? Online is a blast." },
    { user_id: 4, game_id: 5, rating: 3, review: "Had a rough launch, but it's in a much better state now. Night City is stunning." },
    { user_id: 4, game_id: 9, rating: 5, review: "This game is a steal for its price. So much content and challenge." },
    { user_id: 5, game_id: 6, rating: 5, review: "I wish I could experience this for the first time again. A true masterpiece." },
    { user_id: 5, game_id: 8, rating: 5, review: "My cozy corner of the gaming world. I've spent hundreds of hours on my farm." },
    { user_id: 5, game_id: 20, rating: 5, review: "Mind-bending and beautiful. A unique experience that will stick with me forever." },
    { user_id: 5, game_id: 21, rating: 5, review: "The best writing I have ever seen in a video game. Utterly brilliant." },
    { user_id: 6, game_id: 4, rating: 5, review: "A sprawling world with unforgettable characters. The Bloody Baron questline is a masterclass in storytelling." },
    { user_id: 6, game_id: 7, rating: 5, review: "The sense of discovery is unmatched. Every corner of the Lands Between has a secret to uncover." },
    { user_id: 6, game_id: 14, rating: 5, review: "This is how you do a modern RPG. The freedom and reactivity are off the charts." },
    { user_id: 6, game_id: 22, rating: 4, review: "Complex, deep, and rewarding. The combat system takes a while to learn but it's worth it." },
];

export const INITIAL_WISHLIST: WishlistItem[] = [];