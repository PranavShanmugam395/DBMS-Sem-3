import React, { useState } from 'react';
import { User, Game, Purchase, Review, WishlistItem } from './types';
import { INITIAL_USERS, INITIAL_GAMES, INITIAL_PURCHASES, INITIAL_REVIEWS, INITIAL_WISHLIST } from './constants';
import { Header } from './components/Header';
import { UserDashboard } from './components/UserDashboard';
import { DeveloperDashboard } from './components/DeveloperDashboard';
import { Modal } from './components/Modal';

const Login: React.FC<{ onLogin: (username: string, password: string) => void; error: string | null }> = ({ onLogin, error }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onLogin(username, password);
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1b2838] to-[#2a475e]">
            <div className="w-full max-w-sm p-8 bg-gray-800/50 backdrop-blur-sm rounded-lg shadow-2xl border border-gray-700">
                <h1 className="text-3xl font-bold text-center text-white mb-6">Game Store Login</h1>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="username" className="block text-sm font-medium text-gray-300 mb-2">Username</label>
                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full px-4 py-2 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="e.g., Pranav, Sujit, Dev"
                            autoComplete="username"
                        />
                    </div>
                    <div>
                        <label htmlFor="password"  className="block text-sm font-medium text-gray-300 mb-2">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Enter your password"
                            autoComplete="current-password"
                        />
                    </div>
                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                    <button
                        type="submit"
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md transition duration-300"
                    >
                        Login
                    </button>
                </form>
            </div>
        </div>
    );
};


function App() {
    const [users, setUsers] = useState<User[]>(INITIAL_USERS);
    const [games, setGames] = useState<Game[]>(INITIAL_GAMES);
    const [purchases, setPurchases] = useState<Purchase[]>(INITIAL_PURCHASES);
    const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
    const [wishlist, setWishlist] = useState<WishlistItem[]>(INITIAL_WISHLIST);
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [loginError, setLoginError] = useState<string | null>(null);
    const [purchaseSuccessInfo, setPurchaseSuccessInfo] = useState<{ name: string } | null>(null);


    const handleLogin = (username: string, password: string) => {
        const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
        if (user) {
            if (user.password === password) {
                setCurrentUser(user);
                setLoginError(null);
            } else {
                setLoginError("Invalid password.");
            }
        } else {
            setLoginError("User not found.");
        }
    };

    const handleLogout = () => {
        setCurrentUser(null);
    };

    const handlePurchase = (gameId: number, price: number) => {
        if (!currentUser) return;
        
        const alreadyOwned = purchases.some(p => p.user_id === currentUser.user_id && p.game_id === gameId);
        if (alreadyOwned) return;

        if (currentUser.balance < price) {
            console.error("Purchase attempted with insufficient funds.");
            return;
        }

        const updatedUsers = users.map(u => 
            u.user_id === currentUser.user_id ? { ...u, balance: u.balance - price } : u
        );
        setUsers(updatedUsers);
        setCurrentUser(updatedUsers.find(u => u.user_id === currentUser.user_id) || null);
        setPurchases([...purchases, { user_id: currentUser.user_id, game_id: gameId }]);
        
        const purchasedGame = games.find(g => g.game_id === gameId);
        if (purchasedGame) {
            setPurchaseSuccessInfo({ name: purchasedGame.name });
        }
    };

    const handleReview = (gameId: number, rating: number, reviewText: string) => {
        if (!currentUser) return;
        
        const existingReviewIndex = reviews.findIndex(r => r.user_id === currentUser.user_id && r.game_id === gameId);

        if (existingReviewIndex > -1) {
            const updatedReviews = [...reviews];
            updatedReviews[existingReviewIndex] = { ...updatedReviews[existingReviewIndex], rating, review: reviewText };
            setReviews(updatedReviews);
        } else {
            const newReview: Review = { user_id: currentUser.user_id, game_id: gameId, rating, review: reviewText };
            setReviews([...reviews, newReview]);
        }
    };

    const handleAddToWishlist = (gameId: number) => {
        if (!currentUser) return;
        const alreadyInWishlist = wishlist.some(item => item.user_id === currentUser.user_id && item.game_id === gameId);
        if (alreadyInWishlist) return;
        setWishlist([...wishlist, { user_id: currentUser.user_id, game_id: gameId }]);
    };

    const handleRemoveFromWishlist = (gameId: number) => {
        if (!currentUser) return;
        setWishlist(wishlist.filter(item => !(item.user_id === currentUser.user_id && item.game_id === gameId)));
    };
    
    // Developer functions
    const handleAddGame = (name: string, price: number, genre: string, description: string) => {
        const newGame: Game = {
            game_id: games.length > 0 ? Math.max(...games.map(g => g.game_id)) + 1 : 1,
            name,
            price,
            genre,
            imageUrl: `https://picsum.photos/seed/${Math.random()}/400/200`, // Default image for new games
            releaseDate: new Date().toISOString().split('T')[0], // Set current date
            description,
        };
        setGames([...games, newGame]);
    };

    const handleUpdateGame = (gameId: number, newPrice: number) => {
        setGames(games.map(g => g.game_id === gameId ? { ...g, price: newPrice } : g));
    };

    const handleRemoveGame = (gameId: number) => {
        setGames(games.filter(g => g.game_id !== gameId));
    };

    if (!currentUser) {
        return <Login onLogin={handleLogin} error={loginError} />;
    }

    return (
        <div className="bg-[#1b2838] min-h-screen text-gray-300">
            <Header user={currentUser} onLogout={handleLogout} />
            {currentUser.role === 'user' ? (
                <UserDashboard 
                    user={currentUser}
                    games={games}
                    purchases={purchases}
                    reviews={reviews}
                    users={users}
                    wishlist={wishlist}
                    onPurchase={handlePurchase}
                    onReview={handleReview}
                    onAddToWishlist={handleAddToWishlist}
                    onRemoveFromWishlist={handleRemoveFromWishlist}
                />
            ) : (
                <DeveloperDashboard 
                    games={games}
                    reviews={reviews}
                    users={users}
                    purchases={purchases}
                    onAddGame={handleAddGame}
                    onUpdateGame={handleUpdateGame}
                    onRemoveGame={handleRemoveGame}
                />
            )}
            {purchaseSuccessInfo && (
                <Modal 
                    isOpen={!!purchaseSuccessInfo} 
                    onClose={() => setPurchaseSuccessInfo(null)} 
                    title="Purchase Successful!"
                >
                    <div className="text-center p-4">
                        <p className="text-white text-lg mb-6">Congratulations! '{purchaseSuccessInfo.name}' has been added to your library.</p>
                        <button 
                            onClick={() => setPurchaseSuccessInfo(null)}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-8 rounded-lg transition-colors duration-300"
                        >
                            OK
                        </button>
                    </div>
                </Modal>
            )}
        </div>
    );
}

export default App;