import React, { useState, useMemo } from 'react';
import { User, Game, Purchase, Review, WishlistItem } from '../types';
import { StoreIcon, LibraryIcon, ReviewIcon, HeartIcon } from './icons';
import { Modal } from './Modal';

interface UserDashboardProps {
    user: User;
    games: Game[];
    purchases: Purchase[];
    reviews: Review[];
    users: User[];
    wishlist: WishlistItem[];
    onPurchase: (gameId: number, price: number) => void;
    onReview: (gameId: number, rating: number, reviewText: string) => void;
    onAddToWishlist: (gameId: number) => void;
    onRemoveFromWishlist: (gameId: number) => void;
}

type ActiveView = 'store' | 'library' | 'wishlist' | 'review';

const PurchaseModal: React.FC<{
    game: Game;
    reviews: Review[];
    users: User[];
    userBalance: number;
    onClose: () => void;
    onConfirm: () => void;
}> = ({ game, reviews, users, userBalance, onClose, onConfirm }) => {
    const reviewsForGame = reviews.filter(r => r.game_id === game.game_id);
    const [error, setError] = useState<string | null>(null);

    const handleConfirm = () => {
        if (userBalance < game.price) {
            setError('Insufficient balance to complete this purchase.');
            return;
        }
        onConfirm();
    };

    return (
        <Modal isOpen={true} onClose={onClose} title={`Purchase: ${game.name}`}>
            <div className="space-y-4">
                <div className="flex justify-between items-center text-xl">
                    <h3 className="font-bold text-white">{game.name}</h3>
                    <p className="font-semibold text-green-400">₹{game.price}</p>
                </div>
                 <p className="text-gray-300 italic pb-2 border-b border-gray-600">{game.description}</p>

                <div className="pt-2">
                    <h4 className="text-lg font-semibold mb-2 text-white">Community Reviews</h4>
                    <div className="max-h-60 overflow-y-auto space-y-3 pr-2">
                        {reviewsForGame.length > 0 ? (
                            reviewsForGame.map((review, index) => {
                                const user = users.find(u => u.user_id === review.user_id);
                                return (
                                    <div key={index} className="bg-gray-700/50 p-3 rounded-md">
                                        <div className="flex justify-between items-center">
                                            <span className="font-bold text-blue-400">{user?.username || 'Anonymous'}</span>
                                            <span className="text-yellow-400">{'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}</span>
                                        </div>
                                        <p className="text-gray-300 italic mt-1">"{review.review}"</p>
                                    </div>
                                );
                            })
                        ) : (
                            <p className="text-gray-400 text-center py-4">No reviews yet for this game. Be the first!</p>
                        )}
                    </div>
                </div>
                
                {error && <p className="text-red-500 text-sm text-center pt-2">{error}</p>}

                <div className="flex justify-end space-x-4 pt-4 mt-2 border-t border-gray-600">
                    <button onClick={onClose} className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-6 rounded transition-colors duration-300">
                        Cancel
                    </button>
                    <button onClick={handleConfirm} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded transition-colors duration-300">
                        Confirm Purchase
                    </button>
                </div>
            </div>
        </Modal>
    );
};

const GameCard: React.FC<{
    game: Game;
    isOwned: boolean;
    onPurchase: () => void;
    isWishlisted: boolean;
    onToggleWishlist: () => void;
}> = ({ game, isOwned, onPurchase, isWishlisted, onToggleWishlist }) => {
    return (
        <div className="bg-[#2a475e] rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 flex flex-col">
            <div className="relative">
                <img src={game.imageUrl} alt={game.name} className="w-full h-40 object-cover" />
                <button 
                    onClick={onToggleWishlist} 
                    className={`absolute top-2 right-2 p-2 rounded-full transition-colors duration-300 ${isWishlisted ? 'text-red-500 bg-red-900/50' : 'text-gray-300 bg-black/50 hover:text-red-400'}`}
                    aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={isWishlisted ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 116.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z" />
                    </svg>
                </button>
            </div>
            <div className="p-4 flex flex-col flex-grow">
                <h3 className="text-xl font-bold text-white">{game.name}</h3>
                <p className="text-xs text-gray-400 mt-1 mb-2 h-10 overflow-hidden">{game.description}</p>
                <div className="flex-grow"></div>
                <p className="text-sm text-gray-400 mb-2">{game.genre}</p>
                <div className="flex justify-between items-center mt-auto pt-2">
                    <p className="text-lg font-semibold text-green-400">{game.price > 0 ? `₹${game.price}` : 'Free'}</p>
                    {isOwned ? (
                        <span className="text-gray-300 font-bold">In Library</span>
                    ) : (
                        <button onClick={onPurchase} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition-colors duration-300">
                            Purchase
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

const ReviewModal: React.FC<{
    game: Game;
    existingReview: Review | undefined;
    onClose: () => void;
    onReview: (gameId: number, rating: number, reviewText: string) => void;
}> = ({ game, existingReview, onClose, onReview }) => {
    const [rating, setRating] = useState(existingReview?.rating || 3);
    const [reviewText, setReviewText] = useState(existingReview?.review || "");

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onReview(game.game_id, rating, reviewText);
        onClose();
    };

    return (
        <Modal isOpen={true} onClose={onClose} title={`Review: ${game.name}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block mb-2 text-sm font-medium text-gray-300">Rating (1-5)</label>
                    <input type="number" value={rating} onChange={(e) => setRating(Math.max(1, Math.min(5, parseInt(e.target.value, 10))))} className="w-full bg-gray-700 text-white p-2 rounded border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500" min="1" max="5" required />
                </div>
                <div>
                    <label className="block mb-2 text-sm font-medium text-gray-300">Review</label>
                    <textarea value={reviewText} onChange={(e) => setReviewText(e.target.value)} rows={4} className="w-full bg-gray-700 text-white p-2 rounded border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500" required></textarea>
                </div>
                <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors duration-300">
                    {existingReview ? "Update Review" : "Submit Review"}
                </button>
            </form>
        </Modal>
    );
};

export const UserDashboard: React.FC<UserDashboardProps> = ({ user, games, purchases, reviews, users, wishlist, onPurchase, onReview, onAddToWishlist, onRemoveFromWishlist }) => {
    const [activeView, setActiveView] = useState<ActiveView>('store');
    const [selectedGameForReview, setSelectedGameForReview] = useState<Game | null>(null);
    const [gameToPurchase, setGameToPurchase] = useState<Game | null>(null);
    const [selectedGenre, setSelectedGenre] = useState('All');
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOption, setSortOption] = useState('name-asc');

    const ownedGameIds = useMemo(() => purchases.filter(p => p.user_id === user.user_id).map(p => p.game_id), [purchases, user.user_id]);
    const ownedGames = useMemo(() => games.filter(g => ownedGameIds.includes(g.game_id)), [games, ownedGameIds]);
    const wishlistedGameIds = useMemo(() => wishlist.filter(w => w.user_id === user.user_id).map(w => w.game_id), [wishlist, user.user_id]);

    const genres = useMemo(() => ['All', ...Array.from(new Set(games.map(g => g.genre)))].sort(), [games]);
    
    const renderContent = () => {
        const lowerCaseSearchTerm = searchTerm.toLowerCase();

        switch (activeView) {
            case 'store':
                const filteredStoreGames = games.filter(game =>
                    (selectedGenre === 'All' || game.genre === selectedGenre) &&
                    game.name.toLowerCase().includes(lowerCaseSearchTerm)
                );
                
                const sortedGames = [...filteredStoreGames].sort((a, b) => {
                    switch (sortOption) {
                        case 'name-asc': return a.name.localeCompare(b.name);
                        case 'name-desc': return b.name.localeCompare(a.name);
                        case 'price-asc': return a.price - b.price;
                        case 'price-desc': return b.price - a.price;
                        case 'new-trending': return new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime();
                        case 'top-grossing': {
                            const revenueA = (purchases.filter(p => p.game_id === a.game_id).length) * a.price;
                            const revenueB = (purchases.filter(p => p.game_id === b.game_id).length) * b.price;
                            return revenueB - revenueA;
                        }
                        default: return 0;
                    }
                });

                return (
                    <div>
                        <div className="mb-6 flex flex-wrap gap-2">
                            {genres.map(genre => (
                                <button
                                    key={genre}
                                    onClick={() => setSelectedGenre(genre)}
                                    className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors duration-200 ${selectedGenre === genre ? 'bg-blue-600 text-white' : 'bg-[#2a475e] text-gray-300 hover:bg-blue-500'}`}
                                >
                                    {genre}
                                </button>
                            ))}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {sortedGames.map(game => (
                                <GameCard
                                    key={game.game_id}
                                    game={game}
                                    isOwned={ownedGameIds.includes(game.game_id)}
                                    onPurchase={() => setGameToPurchase(game)}
                                    isWishlisted={wishlistedGameIds.includes(game.game_id)}
                                    onToggleWishlist={() => {
                                        if (wishlistedGameIds.includes(game.game_id)) {
                                            onRemoveFromWishlist(game.game_id);
                                        } else {
                                            onAddToWishlist(game.game_id);
                                        }
                                    }}
                                />
                            ))}
                        </div>
                    </div>
                );
            case 'library':
                const filteredLibraryGames = ownedGames.filter(game =>
                    game.name.toLowerCase().includes(lowerCaseSearchTerm)
                );
                return filteredLibraryGames.length > 0 ? (
                    <div className="bg-[#2a475e]/50 rounded-lg p-6">
                        <ul className="space-y-3">
                            {filteredLibraryGames.map(game => (
                                <li key={game.game_id} className="text-lg text-white p-3 bg-gray-700/50 rounded">{game.name}</li>
                            ))}
                        </ul>
                    </div>
                ) : <p className="text-center text-xl text-gray-400 mt-10">No games found in your library.</p>;
            case 'wishlist':
                const wishlistedGames = games.filter(g => wishlistedGameIds.includes(g.game_id));
                return wishlistedGames.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {wishlistedGames.map(game => (
                            <GameCard
                                key={game.game_id}
                                game={game}
                                isOwned={ownedGameIds.includes(game.game_id)}
                                onPurchase={() => setGameToPurchase(game)}
                                isWishlisted={true}
                                onToggleWishlist={() => onRemoveFromWishlist(game.game_id)}
                            />
                        ))}
                    </div>
                ) : <p className="text-center text-xl text-gray-400 mt-10">Your wishlist is empty. Add games from the store!</p>;
            case 'review':
                return ownedGames.length > 0 ? (
                    <div className="bg-[#2a475e]/50 rounded-lg p-6">
                        <h3 className="text-2xl font-bold mb-4 text-white">Rate & Review Your Games</h3>
                        <ul className="space-y-4">
                            {ownedGames.map(game => {
                                const userReview = reviews.find(r => r.user_id === user.user_id && r.game_id === game.game_id);
                                return (
                                    <li key={game.game_id} className="flex justify-between items-center p-4 bg-gray-700/50 rounded">
                                        <div>
                                            <p className="text-lg text-white">{game.name}</p>
                                            {userReview && <p className="text-sm text-gray-400 italic">"{userReview.review}" ({userReview.rating}/5)</p>}
                                        </div>
                                        <button onClick={() => setSelectedGameForReview(game)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded transition-colors duration-300">
                                            {userReview ? "Edit Review" : "Write Review"}
                                        </button>
                                    </li>
                                );
                            })}
                        </ul>
                    </div>
                ) : <p className="text-center text-xl text-gray-400 mt-10">Purchase a game to review it.</p>;
        }
    };
    
    const navItems = [
        { id: 'store', icon: <StoreIcon />, label: 'Store' },
        { id: 'library', icon: <LibraryIcon />, label: 'Library' },
        { id: 'wishlist', icon: <HeartIcon />, label: 'Wishlist' },
        { id: 'review', icon: <ReviewIcon />, label: 'Reviews' },
    ];

    return (
        <div className="flex">
            <nav className="w-64 bg-gray-800/50 p-4 space-y-4 min-h-screen">
                 {navItems.map(item => (
                    <button
                        key={item.id}
                        onClick={() => {
                            setActiveView(item.id as ActiveView);
                            if (item.id === 'store') setSelectedGenre('All');
                            setSearchTerm(''); 
                        }}
                        className={`w-full flex items-center p-3 rounded-lg text-lg transition-colors duration-200 ${activeView === item.id ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700'}`}
                    >
                        {item.icon}
                        {item.label}
                    </button>
                ))}
            </nav>
            <main className="flex-1 p-8">
                <div className="mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
                    {(activeView === 'store' || activeView === 'library') && (
                        <input
                            type="text"
                            placeholder={activeView === 'store' ? "Search all games..." : "Search your library..."}
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full md:w-auto md:flex-grow max-w-lg p-2 bg-[#2a475e] text-white rounded border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    )}
                     {activeView === 'store' && (
                        <div className="flex items-center">
                             <label htmlFor="sort-games" className="text-sm mr-2 text-gray-400">Sort by:</label>
                             <select 
                                id="sort-games" 
                                value={sortOption} 
                                onChange={e => setSortOption(e.target.value)} 
                                className="p-2 bg-[#2a475e] text-white rounded border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                <option value="name-asc">Name (A-Z)</option>
                                <option value="name-desc">Name (Z-A)</option>
                                <option value="price-asc">Price: Low to High</option>
                                <option value="price-desc">Price: High to Low</option>
                                <option value="new-trending">New & Trending</option>
                                <option value="top-grossing">Top Grossing</option>
                            </select>
                        </div>
                    )}
                </div>
                {renderContent()}
            </main>
            {selectedGameForReview && (
                <ReviewModal
                    game={selectedGameForReview}
                    existingReview={reviews.find(r => r.user_id === user.user_id && r.game_id === selectedGameForReview.game_id)}
                    onClose={() => setSelectedGameForReview(null)}
                    onReview={onReview}
                />
            )}
            {gameToPurchase && (
                <PurchaseModal
                    game={gameToPurchase}
                    reviews={reviews}
                    users={users}
                    userBalance={user.balance}
                    onClose={() => setGameToPurchase(null)}
                    onConfirm={() => {
                        onPurchase(gameToPurchase.game_id, gameToPurchase.price);
                        setGameToPurchase(null);
                    }}
                />
            )}
        </div>
    );
};