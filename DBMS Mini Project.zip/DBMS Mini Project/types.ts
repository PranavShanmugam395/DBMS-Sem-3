export interface User {
  user_id: number;
  username: string;
  password: string;
  balance: number;
  role: 'user' | 'developer';
}

export interface Game {
  game_id: number;
  name: string;
  price: number;
  imageUrl: string;
  genre: string;
  releaseDate: string; // YYYY-MM-DD
  description: string;
}

export interface Purchase {
  user_id: number;
  game_id: number;
}

export interface Review {
  user_id: number;
  game_id: number;
  rating: number;
  review: string;
}

export interface WishlistItem {
  user_id: number;
  game_id: number;
}