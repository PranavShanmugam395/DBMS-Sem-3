export interface User {
  user_id: number;
  username: string;
  password: string;
  balance: number;
  role: 'user' | 'developer';
}

export interface Game {
  game_id: number;
  name: string;
  price: number;
  imageUrl: string;
  genre: string;
  releaseDate: string; // YYYY-MM-DD
  description: string;
}

export interface Purchase {
  purchase_id: number;
  user_id: number;
  game_id: number;
  purchase_date: string;
}

export interface Review {
  review_id: number;
  user_id: number;
  game_id: number;
  rating: number;
  review: string;
}

export interface WishlistItem {
  wishlist_id: number;
  user_id: number;
  game_id: number;
}

export interface QueryLog {
  timestamp: string;
  query: string;
  status: 'SUCCESS' | 'ERROR';
}
