import { supabase } from './supabaseClient';
import { User } from './types';

const SIMULATED_DELAY = 600; // Keep a small delay to make loading states visible

// --- AUTH ---
export const apiLogin = async (username: string, password: string): Promise<{ user: User | null; error?: string }> => {
    // In a real app, you'd use Supabase Auth. For this project, we'll find the user in our custom table.
    const { data: user, error } = await supabase
        .from('users')
        .select('*')
        .eq('username', username)
        .single();

    // Fix: Check for both error and null user, as .single() can return null data without an error if no row is found.
    if (error || !user) {
        return { user: null, error: "User not found." };
    }
    if (user.password !== password) {
        return { user: null, error: "Invalid password." };
    }
    return { user };
};


// --- DATA FETCHING ---
export const apiFetchInitialData = async (userId: number) => {
    // Fetch all static or semi-static data
    const [gamesRes, usersRes, reviewsRes] = await Promise.all([
        supabase.from('games').select('*'),
        supabase.from('users').select('*'),
        supabase.from('reviews').select('*')
    ]);

    // Fetch user-specific data
    const [purchasesRes, wishlistRes] = await Promise.all([
        supabase.from('purchases').select('*').eq('user_id', userId),
        supabase.from('wishlist').select('*').eq('user_id', userId)
    ]);

    // Check for errors
    const errors = [gamesRes.error, usersRes.error, reviewsRes.error, purchasesRes.error, wishlistRes.error].filter(Boolean);
    if (errors.length > 0) {
        console.error("Error fetching data:", errors);
        return { data: null, error: errors[0]?.message };
    }

    return {
      data: {
          games: gamesRes.data,
          users: usersRes.data,
          reviews: reviewsRes.data,
          purchases: purchasesRes.data,
          wishlist: wishlistRes.data
      },
      error: null
    };
}


// --- USER ACTIONS ---
export const apiPurchaseGame = async (userId: number, gameId: number, price: number, currentBalance: number) => {
    if (currentBalance < price) {
        return { success: false, error: "Insufficient balance." };
    }

    const newBalance = currentBalance - price;

    // In a real database, you'd use a transaction here.
    // Supabase Edge Functions are the best way to do that. For now, we do two separate calls.
    const { error: purchaseError } = await supabase.from('purchases').insert({ user_id: userId, game_id: gameId });
    if (purchaseError) return { success: false, error: purchaseError.message };

    const { data: updatedUser, error: userError } = await supabase
        .from('users')
        .update({ balance: newBalance })
        .eq('user_id', userId)
        .select()
        .single();
    
    if (userError) return { success: false, error: userError.message };

    return { success: true, data: { updatedUser } };
};

export const apiSubmitReview = async (userId: number, gameId: number, rating: number, reviewText: string) => {
    // 'upsert' will either insert a new review or update an existing one based on the primary key/unique constraints.
    // Since we want one review per user per game, we'll check first.
    
    const { data: existing, error: findError } = await supabase
        .from('reviews')
        .select('review_id')
        .eq('user_id', userId)
        .eq('game_id', gameId)
        .single();

    if (existing) { // Update
        const { error } = await supabase.from('reviews').update({ rating, review: reviewText }).eq('review_id', existing.review_id);
        if(error) return { success: false, error: error.message };
    } else { // Insert
        const { error } = await supabase.from('reviews').insert({ user_id: userId, game_id: gameId, rating, review: reviewText });
        if(error) return { success: false, error: error.message };
    }

    // Return all reviews to refresh the state
    const { data: updatedReviews } = await supabase.from('reviews').select('*');
    return { success: true, data: { updatedReviews } };
}

export const apiAddToWishlist = async (userId: number, gameId: number) => {
    const { error } = await supabase.from('wishlist').insert({ user_id: userId, game_id: gameId });
    if(error) return { success: false, error: error.message };
    const { data: updatedWishlist } = await supabase.from('wishlist').select('*').eq('user_id', userId);
    return { success: true, data: { updatedWishlist } };
}

export const apiRemoveFromWishlist = async (userId: number, gameId: number) => {
    const { error } = await supabase.from('wishlist').delete().match({ user_id: userId, game_id: gameId });
    if(error) return { success: false, error: error.message };
    const { data: updatedWishlist } = await supabase.from('wishlist').select('*').eq('user_id', userId);
    return { success: true, data: { updatedWishlist } };
}

// --- DEVELOPER ACTIONS ---
export const apiAddGame = async (name: string, price: number, genre: string, description: string) => {
    const newGame = {
        name,
        price,
        genre,
        imageUrl: `https://picsum.photos/seed/${Math.random()}/400/200`,
        releaseDate: new Date().toISOString().split('T')[0],
        description,
    };
    const { error } = await supabase.from('games').insert(newGame);
    if(error) return { success: false, error: error.message };
    return { success: true };
}

export const apiUpdateGame = async (gameId: number, newPrice: number) => {
    const { error } = await supabase.from('games').update({ price: newPrice }).eq('game_id', gameId);
    if(error) return { success: false, error: error.message };
    return { success: true };
}

export const apiRemoveGame = async (gameId: number) => {
    // The database is set up with 'ON DELETE CASCADE', so deleting a game will automatically
    // remove related purchases, reviews, and wishlist items. This is a key RDBMS feature!
    const { error } = await supabase.from('games').delete().eq('game_id', gameId);
    if(error) return { success: false, error: error.message };
    return { success: true };
}
