import React, { useState, useEffect } from 'react';
import { User, Game, Purchase, Review, WishlistItem } from './types';
import { Header } from './components/Header';
import { UserDashboard } from './components/UserDashboard';
import { DeveloperDashboard } from './components/DeveloperDashboard';
import { Modal } from './components/Modal';
import * as api from './api';

const Login: React.FC<{ onLogin: (username: string, password: string) => void; error: string | null; isLoading: boolean; }> = ({ onLogin, error, isLoading }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onLogin(username, password);
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1b2838] to-[#2a475e]">
            <div className="w-full max-w-sm p-8 bg-gray-800/50 backdrop-blur-sm rounded-lg shadow-2xl border border-gray-700">
                <h1 className="text-3xl font-bold text-center text-white mb-6">Game Store Login</h1>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="username" className="block text-sm font-medium text-gray-300 mb-2">Username</label>
                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full px-4 py-2 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="e.g., Pranav, Sujit, Dev"
                            autoComplete="username"
                            disabled={isLoading}
                        />
                    </div>
                    <div>
                        <label htmlFor="password"  className="block text-sm font-medium text-gray-300 mb-2">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Enter your password"
                            autoComplete="current-password"
                            disabled={isLoading}
                        />
                    </div>

                    <div className="!mt-8 border-t border-gray-600 pt-6">
                        <h3 className="text-sm font-bold text-center text-gray-400 mb-4">PostgreSQL Connection</h3>
                        <div className="space-y-3">
                             <div className="flex items-center">
                                <label className="w-1/3 text-xs text-gray-400">Host:</label>
                                <input type="text" value="db.xxxxxxxx.supabase.co" className="flex-grow px-2 py-1 text-xs bg-gray-900/50 text-gray-300 rounded-sm border border-gray-600" disabled />
                            </div>
                            <div className="flex items-center">
                                <label className="w-1/3 text-xs text-gray-400">Port:</label>
                                <input type="text" value="5432" className="flex-grow px-2 py-1 text-xs bg-gray-900/50 text-gray-300 rounded-sm border border-gray-600" disabled />
                            </div>
                            <div className="flex items-center">
                                <label className="w-1/3 text-xs text-gray-400">DB Name:</label>
                                <input type="text" value="postgres" className="flex-grow px-2 py-1 text-xs bg-gray-900/50 text-gray-300 rounded-sm border border-gray-600" disabled />
                            </div>
                        </div>
                    </div>


                    {error && <p className="text-red-500 text-sm text-center !mt-6">{error}</p>}
                    <button
                        type="submit"
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md transition duration-300 disabled:bg-gray-500 !mt-8"
                        disabled={isLoading}
                    >
                        {isLoading ? 'Connecting & Logging In...' : 'Login'}
                    </button>
                </form>
            </div>
        </div>
    );
};

const LoadingOverlay: React.FC<{text: string}> = ({text}) => (
    <div className="fixed inset-0 bg-black/50 flex flex-col justify-center items-center z-50">
        <svg className="animate-spin h-10 w-10 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="mt-4 text-white">{text}</p>
    </div>
);


function App() {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [loginError, setLoginError] = useState<string | null>(null);
    const [isAppLoading, setAppLoading] = useState<boolean>(false);
    const [loadingText, setLoadingText] = useState('Loading...');
    
    // Data state, populated from API
    const [users, setUsers] = useState<User[]>([]);
    const [games, setGames] = useState<Game[]>([]);
    const [purchases, setPurchases] = useState<Purchase[]>([]);
    const [reviews, setReviews] = useState<Review[]>([]);
    const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
    
    const [purchaseSuccessInfo, setPurchaseSuccessInfo] = useState<{ name: string } | null>(null);
    const [dbStatus, setDbStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');

    const fetchAllData = async (user: User) => {
        setLoadingText('Querying database...');
        setAppLoading(true);
        const { data, error } = await api.apiFetchInitialData(user.user_id);
        if (data) {
            setGames(data.games || []);
            setUsers(data.users || []);
            setReviews(data.reviews || []);
            setPurchases(data.purchases || []);
            setWishlist(data.wishlist || []);
        } else {
            console.error("Failed to fetch data:", error);
            // Handle data fetch error, maybe show a message
        }
        setAppLoading(false);
    };
    
    const handleLogin = async (username: string, password: string) => {
        setAppLoading(true);
        setLoadingText('Authenticating...');
        const { user, error } = await api.apiLogin(username, password);
        if (user) {
            setDbStatus('connecting');
            setCurrentUser(user);
            setLoginError(null);
            
            await fetchAllData(user); // Fetch all data after login
            setDbStatus('connected');

        } else {
            setLoginError(error || "An unknown error occurred.");
            setAppLoading(false);
        }
    };

    const handleLogout = () => {
        setCurrentUser(null);
        setDbStatus('disconnected');
        // Clear all data
        setGames([]); setUsers([]); setReviews([]); setPurchases([]); setWishlist([]);
    };

    const handlePurchase = async (gameId: number, price: number) => {
        if (!currentUser) return;
        setAppLoading(true);
        setLoadingText('Processing purchase...');
        const { data, success } = await api.apiPurchaseGame(currentUser.user_id, gameId, price, currentUser.balance);

        if (success && data?.updatedUser) {
            setCurrentUser(data.updatedUser); // Update user balance in state
            setPurchases(prev => [...prev, { user_id: currentUser.user_id, game_id: gameId }]); // Optimistically add purchase
            const purchasedGame = games.find(g => g.game_id === gameId);
            if (purchasedGame) setPurchaseSuccessInfo({ name: purchasedGame.name });
        }
        setAppLoading(false);
    };

    const handleReview = async (gameId: number, rating: number, reviewText: string) => {
        if (!currentUser) return;
        setAppLoading(true);
        setLoadingText('Submitting review...');
        const { data, success } = await api.apiSubmitReview(currentUser.user_id, gameId, rating, reviewText);
        if (success && data?.updatedReviews) {
            setReviews(data.updatedReviews);
        }
        setAppLoading(false);
    };

    const handleAddToWishlist = async (gameId: number) => {
        if (!currentUser) return;
        setAppLoading(true);
        setLoadingText('Updating wishlist...');
        const { data, success } = await api.apiAddToWishlist(currentUser.user_id, gameId);
        if (success && data?.updatedWishlist) {
            setWishlist(data.updatedWishlist);
        }
        setAppLoading(false);
    };

    const handleRemoveFromWishlist = async (gameId: number) => {
        if (!currentUser) return;
        setAppLoading(true);
        setLoadingText('Updating wishlist...');
        const { data, success } = await api.apiRemoveFromWishlist(currentUser.user_id, gameId);
        if (success && data?.updatedWishlist) {
            setWishlist(data.updatedWishlist);
        }
        setAppLoading(false);
    };
    
    const handleAddGame = async (name: string, price: number, genre: string, description: string) => {
        setAppLoading(true);
        setLoadingText('Adding game...');
        const { success } = await api.apiAddGame(name, price, genre, description);
        if (success) {
            await fetchAllData(currentUser!); // Refetch data to see the new game
        }
        setAppLoading(false);
    };

    const handleUpdateGame = async (gameId: number, newPrice: number) => {
        setAppLoading(true);
        setLoadingText('Updating price...');
        const { success } = await api.apiUpdateGame(gameId, newPrice);
        if (success) {
            await fetchAllData(currentUser!); // Refetch data
        }
        setAppLoading(false);
    };

    const handleRemoveGame = async (gameId: number) => {
        setAppLoading(true);
        setLoadingText('Removing game...');
        const { success } = await api.apiRemoveGame(gameId);
        if (success) {
            await fetchAllData(currentUser!); // Refetch data
        }
        setAppLoading(false);
    };

    if (!currentUser) {
        return <Login onLogin={handleLogin} error={loginError} isLoading={isAppLoading} />;
    }

    return (
        <div className="bg-[#1b2838] min-h-screen text-gray-300">
            {isAppLoading && <LoadingOverlay text={loadingText}/>}
            <Header user={currentUser} onLogout={handleLogout} dbStatus={dbStatus} />
            {currentUser.role === 'user' ? (
                <UserDashboard 
                    user={currentUser}
                    games={games}
                    purchases={purchases}
                    reviews={reviews}
                    users={users}
                    wishlist={wishlist}
                    onPurchase={handlePurchase}
                    onReview={handleReview}
                    onAddToWishlist={handleAddToWishlist}
                    onRemoveFromWishlist={handleRemoveFromWishlist}
                    isAppLoading={isAppLoading}
                />
            ) : (
                <DeveloperDashboard 
                    games={games}
                    reviews={reviews}
                    users={users}
                    purchases={purchases} // Pass all purchases for analytics
                    onAddGame={handleAddGame}
                    onUpdateGame={handleUpdateGame}
                    onRemoveGame={handleRemoveGame}
                    isAppLoading={isAppLoading}
                />
            )}
            {purchaseSuccessInfo && (
                <Modal 
                    isOpen={!!purchaseSuccessInfo} 
                    onClose={() => setPurchaseSuccessInfo(null)} 
                    title="Purchase Successful!"
                >
                    <div className="text-center p-4">
                        <p className="text-white text-lg mb-6">Congratulations! '{purchaseSuccessInfo.name}' has been added to your library.</p>
                        <button 
                            onClick={() => setPurchaseSuccessInfo(null)}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-8 rounded-lg transition-colors duration-300"
                        >
                            OK
                        </button>
                    </div>
                </Modal>
            )}
        </div>
    );
}

export default App;