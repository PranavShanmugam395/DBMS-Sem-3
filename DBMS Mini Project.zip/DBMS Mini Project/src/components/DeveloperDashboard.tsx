import React, { useState, useMemo } from 'react';
import { Game, Review, User, Purchase } from '../types';
import { Modal } from './Modal';
import { TableIcon } from './icons';

interface DeveloperDashboardProps {
    games: Game[];
    reviews: Review[];
    users: User[];
    purchases: Purchase[];
    onAddGame: (name: string, price: number, genre: string, description: string) => void;
    onUpdateGame: (gameId: number, newPrice: number) => void;
    onRemoveGame: (gameId: number) => void;
    isAppLoading: boolean;
}

const AddGameForm: React.FC<{ 
    onAddGame: (name: string, price: number, genre: string, description: string) => void; 
    onClose: () => void;
    genres: string[];
    isLoading: boolean;
}> = ({ onAddGame, onClose, genres, isLoading }) => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [genre, setGenre] = useState(genres[0] || '');
    const [description, setDescription] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onAddGame(name, Number(price), genre, description);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="block mb-2 text-sm font-medium text-gray-300">Game Name</label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-gray-700 text-white p-2 rounded border border-gray-600" required disabled={isLoading} />
            </div>
            <div>
                <label className="block mb-2 text-sm font-medium text-gray-300">Price</label>
                <input type="number" value={price} onChange={e => setPrice(e.target.value)} className="w-full bg-gray-700 text-white p-2 rounded border border-gray-600" required min="0" disabled={isLoading} />
            </div>
            <div>
                <label className="block mb-2 text-sm font-medium text-gray-300">Description</label>
                <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-gray-700 text-white p-2 rounded border border-gray-600" required rows={3} placeholder="A short, one-sentence description of the game." disabled={isLoading} />
            </div>
             <div>
                <label className="block mb-2 text-sm font-medium text-gray-300">Genre</label>
                <select value={genre} onChange={e => setGenre(e.target.value)} className="w-full bg-gray-700 text-white p-2 rounded border border-gray-600" required disabled={isLoading}>
                     <option value="" disabled>Select a genre</option>
                     {genres.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
            </div>
            <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded disabled:bg-gray-500" disabled={isLoading}>
                {isLoading ? 'Adding...' : 'Add Game'}
            </button>
        </form>
    );
};

const UpdateGameForm: React.FC<{ game: Game; onUpdateGame: (gameId: number, newPrice: number) => void; onClose: () => void; isLoading: boolean; }> = ({ game, onUpdateGame, onClose, isLoading }) => {
    const [price, setPrice] = useState(game.price.toString());

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onUpdateGame(game.game_id, Number(price));
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="block mb-2 text-sm font-medium text-gray-300">New Price for {game.name}</label>
                <input type="number" value={price} onChange={e => setPrice(e.target.value)} className="w-full bg-gray-700 text-white p-2 rounded border border-gray-600" required min="0" disabled={isLoading}/>
            </div>
            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:bg-gray-500" disabled={isLoading}>
                {isLoading ? 'Updating...' : 'Update Price'}
            </button>
        </form>
    );
};

const SchemaViewer: React.FC = () => {
    const schema = {
        users: [
            { column: 'user_id', type: 'INT', constraints: 'PRIMARY KEY, AUTO_INCREMENT' },
            { column: 'username', type: 'VARCHAR(255)', constraints: 'NOT NULL, UNIQUE' },
            { column: 'password', type: 'VARCHAR(255)', constraints: 'NOT NULL' },
            { column: 'balance', type: 'DECIMAL(10, 2)', constraints: 'NOT NULL, DEFAULT 5000.00' },
            { column: 'role', type: "ENUM('user', 'developer')", constraints: 'NOT NULL' },
        ],
        games: [
            { column: 'game_id', type: 'INT', constraints: 'PRIMARY KEY, AUTO_INCREMENT' },
            { column: 'name', type: 'VARCHAR(255)', constraints: 'NOT NULL' },
            { column: 'price', type: 'DECIMAL(10, 2)', constraints: 'NOT NULL' },
            { column: 'imageUrl', type: 'VARCHAR(255)', constraints: '' },
            { column: 'genre', type: 'VARCHAR(100)', constraints: '' },
            { column: 'releaseDate', type: 'DATE', constraints: '' },
            { column: 'description', type: 'TEXT', constraints: '' },
        ],
        purchases: [
            { column: 'purchase_id', type: 'INT', constraints: 'PRIMARY KEY, AUTO_INCREMENT' },
            { column: 'user_id', type: 'INT', constraints: 'FOREIGN KEY (users.user_id)' },
            { column: 'game_id', type: 'INT', constraints: 'FOREIGN KEY (games.game_id)' },
            { column: 'purchase_date', type: 'TIMESTAMP', constraints: 'DEFAULT CURRENT_TIMESTAMP' },
        ],
         reviews: [
            { column: 'review_id', type: 'INT', constraints: 'PRIMARY KEY, AUTO_INCREMENT' },
            { column: 'user_id', type: 'INT', constraints: 'FOREIGN KEY (users.user_id)' },
            { column: 'game_id', type: 'INT', constraints: 'FOREIGN KEY (games.game_id)' },
            { column: 'rating', type: 'INT', constraints: 'CHECK (rating >= 1 AND rating <= 5)' },
            { column: 'review', type: 'TEXT', constraints: '' },
        ],
        wishlist: [
            { column: 'wishlist_id', type: 'INT', constraints: 'PRIMARY KEY, AUTO_INCREMENT' },
            { column: 'user_id', type: 'INT', constraints: 'FOREIGN KEY (users.user_id)' },
            { column: 'game_id', type: 'INT', constraints: 'FOREIGN KEY (games.game_id)' },
        ],
    };

    return (
        <div className="bg-[#2a475e]/50 p-6 rounded-lg">
            <h3 className="text-2xl font-bold mb-6 text-white">PostgreSQL Database Schema</h3>
            <div className="space-y-8">
                {Object.entries(schema).map(([tableName, columns]) => (
                    <div key={tableName}>
                        <h4 className="text-xl font-semibold text-cyan-300 mb-2 font-mono">`{tableName}`</h4>
                        <table className="w-full text-left bg-gray-700/30 rounded-md">
                            <thead className="bg-gray-800/50">
                                <tr>
                                    <th className="p-3">Column Name</th>
                                    <th className="p-3">Data Type</th>
                                    <th className="p-3">Constraints</th>
                                </tr>
                            </thead>
                            <tbody>
                                {columns.map(col => (
                                    <tr key={col.column} className="border-t border-gray-600">
                                        <td className="p-3 font-mono">{col.column}</td>
                                        <td className="p-3 font-mono text-yellow-400">{col.type}</td>
                                        <td className="p-3 font-mono text-gray-400">{col.constraints}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ))}
            </div>
        </div>
    );
};


export const DeveloperDashboard: React.FC<DeveloperDashboardProps> = ({ games, reviews, users, purchases, onAddGame, onUpdateGame, onRemoveGame, isAppLoading }) => {
    const [activeView, setActiveView] = useState<'manage' | 'schema'>('manage');
    const [isAddModalOpen, setAddModalOpen] = useState(false);
    const [gameToUpdate, setGameToUpdate] = useState<Game | null>(null);
    
    const genres = useMemo(() => [...new Set(games.map(g => g.genre))].sort(), [games]);

    const totalRevenue = useMemo(() => {
        return purchases.reduce((total, purchase) => {
            const game = games.find(g => g.game_id === purchase.game_id);
            return total + (game ? game.price : 0);
        }, 0);
    }, [purchases, games]);


    return (
        <div className="p-8">
            <h2 className="text-4xl font-bold mb-2 text-white">Developer Dashboard</h2>
             <div className="mb-8 bg-green-800/50 p-4 rounded-lg shadow-lg inline-block">
                 <p className="text-lg text-gray-300">Total Revenue Generated</p>
                 <p className="text-3xl font-bold text-green-400">₹{totalRevenue.toFixed(2)}</p>
            </div>
            
             <div className="mb-8 border-b border-gray-700 flex space-x-2">
                <button onClick={() => setActiveView('manage')} className={`px-4 py-2 text-lg font-semibold ${activeView === 'manage' ? 'border-b-2 border-blue-500 text-white' : 'text-gray-400'}`}>Management</button>
                <button onClick={() => setActiveView('schema')} className={`px-4 py-2 text-lg font-semibold ${activeView === 'schema' ? 'border-b-2 border-blue-500 text-white' : 'text-gray-400'}`}>Schema</button>
            </div>

            {activeView === 'manage' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Game Management Section */}
                    <div className="bg-[#2a475e]/50 p-6 rounded-lg">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-2xl font-bold text-white">Manage Games</h3>
                            <button onClick={() => setAddModalOpen(true)} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded disabled:bg-gray-500" disabled={isAppLoading}>Add New Game</button>
                        </div>
                        <ul className="space-y-3 max-h-96 overflow-y-auto pr-2">
                            {games.map(game => (
                                <li key={game.game_id} className="flex justify-between items-center bg-gray-700/50 p-3 rounded">
                                    <div>
                                        <p className="text-white font-semibold">{game.name}</p>
                                        <p className="text-sm text-gray-400">{game.genre} - <span className="text-green-400">₹{game.price}</span></p>
                                    </div>
                                    <div className="space-x-2">
                                        <button onClick={() => setGameToUpdate(game)} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-1 px-3 rounded text-sm disabled:bg-gray-500" disabled={isAppLoading}>Update</button>
                                        <button onClick={() => onRemoveGame(game.game_id)} className="bg-red-600 hover:bg-red-700 text-white font-semibold py-1 px-3 rounded text-sm disabled:bg-gray-500" disabled={isAppLoading}>Remove</button>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* All Reviews Section */}
                    <div className="bg-[#2a475e]/50 p-6 rounded-lg">
                        <h3 className="text-2xl font-bold mb-4 text-white">All Reviews</h3>
                        {reviews.length > 0 ? (
                            <ul className="space-y-4 max-h-96 overflow-y-auto pr-2">
                                {reviews.map((review, index) => {
                                    const user = users.find(u => u.user_id === review.user_id);
                                    const game = games.find(g => g.game_id === review.game_id);
                                    return (
                                        <li key={index} className="bg-gray-700/50 p-4 rounded">
                                            <p className="text-white">
                                                <span className="font-bold text-blue-400">{user?.username || 'Unknown User'}</span> reviewed 
                                                <span className="font-bold text-green-400"> {game?.name || 'Unknown Game'}</span>
                                            </p>
                                            <p className="text-yellow-400">Rating: {review.rating}/5</p>
                                            <p className="text-gray-300 italic mt-1">"{review.review}"</p>
                                        </li>
                                    );
                                })}
                            </ul>
                        ) : (
                            <p className="text-gray-400 text-center mt-10">No reviews have been submitted yet.</p>
                        )}
                    </div>
                </div>
            ) : (
                 <SchemaViewer />
            )}


            <Modal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} title="Add New Game">
                <AddGameForm onAddGame={(...args) => { onAddGame(...args); setAddModalOpen(false); }} onClose={() => setAddModalOpen(false)} genres={genres} isLoading={isAppLoading} />
            </Modal>
            
            {gameToUpdate && (
                <Modal isOpen={!!gameToUpdate} onClose={() => setGameToUpdate(null)} title="Update Game Price">
                    <UpdateGameForm game={gameToUpdate} onUpdateGame={(...args) => { onUpdateGame(...args); setGameToUpdate(null); }} onClose={() => setGameToUpdate(null)} isLoading={isAppLoading} />
                </Modal>
            )}
        </div>
    );
};