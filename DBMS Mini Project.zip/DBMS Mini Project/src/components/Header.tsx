import React from 'react';
import { User } from '../types';
import { GamepadIcon, DatabaseIcon } from './icons';

interface HeaderProps {
    user: User;
    onLogout: () => void;
    dbStatus: 'connecting' | 'connected' | 'disconnected';
}

export const Header: React.FC<HeaderProps> = ({ user, onLogout, dbStatus }) => {
    const isConnecting = dbStatus === 'connecting';
    const isConnected = dbStatus === 'connected';
    return (
        <header className="bg-gray-800/50 backdrop-blur-sm p-4 flex justify-between items-center sticky top-0 z-50 shadow-lg">
            <div className="flex items-center space-x-4">
                <GamepadIcon />
                <h1 className="text-xl font-bold text-white">Steam Clone</h1>
            </div>
            <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                    <DatabaseIcon />
                    <span className={`text-sm font-semibold ${isConnecting ? 'text-yellow-400' : isConnected ? 'text-green-400' : 'text-red-400'}`}>
                        PostgreSQL DB:
                    </span>
                    <div className="flex items-center space-x-1.5">
                        <span className={`h-2 w-2 rounded-full ${isConnecting ? 'bg-yellow-400 animate-pulse' : isConnected ? 'bg-green-400' : 'bg-red-400'}`}></span>
                        <span className="text-sm">{isConnecting ? 'Connecting...' : isConnected ? 'Connected' : 'Disconnected'}</span>
                    </div>
                </div>

                <div className="text-right">
                    <p className="text-gray-300">Welcome, <span className="font-semibold text-white">{user.username}</span></p>
                    {user.role === 'user' && <p className="text-sm text-green-400">Balance: ₹{user.balance.toFixed(2)}</p>}
                </div>
                <button
                    onClick={onLogout}
                    className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md transition duration-300"
                >
                    Logout
                </button>
            </div>
        </header>
    );
};